from tkinter import ON
from flask import Flask
from flask import render_template, redirect, url_for, request
import psycopg2

#establishing the connection
conn = psycopg2.connect(database='DMQL_project', user='postgres', password='abc@123')
cursor = conn.cursor()

app = Flask(__name__)

@app.route('/index', methods=['GET', 'POST'])
def index():
    error = None
    #Retrieving data
    cursor.execute('''SELECT * from login ''')

    #Fetching 1st row from the table
    result = cursor.fetchone()
    if request.method == 'POST':
        if request.form['username']!=result[0] or request.form['password'] != result[1]:
            error = 'Invalid Credentials. Please try again.'
            return redirect(url_for('index'), msg=error)
        else:
            print("login successful")
            return render_template('dashboard.html', msg=error)
    return render_template('index.html', msg=error)

@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    error = None
    
    return render_template('dashboard.html', error=error)

if __name__ == '__main__':
    app.run()